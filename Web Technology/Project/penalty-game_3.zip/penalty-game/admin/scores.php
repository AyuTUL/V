<?php
require_once '../config.php';
requireAdmin();
$activePage = 'scores';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Scores — Admin</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="main">
    <div class="page-hd">
        <h1>All Scores</h1>
        <p>View and edit every player's game history</p>
    </div>

    <div class="card" style="margin-bottom:20px">
        <div class="card-hd"><span class="card-hd-title">Leaderboard Summary</span></div>
        <div style="overflow-x:auto">
            <table class="tbl">
                <thead><tr>
                    <th>#</th><th>Player</th><th>Games</th>
                    <th>Goals Scored</th><th>Saves</th><th>Lifelines</th><th>Last Played</th>
                </tr></thead>
                <tbody id="lb-tbody">
                    <tr><td colspan="7" style="text-align:center;color:var(--dim);padding:20px">Loading...</td></tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-hd">
            <span class="card-hd-title">Game History</span>
            <div style="display:flex;gap:8px;align-items:center">
                <input type="text" class="search-input" id="search" placeholder="Filter by player...">
                <button class="btn btn-ghost" onclick="loadScores()" style="font-size:11px;padding:6px 14px">Refresh</button>
            </div>
        </div>
        <div style="overflow-x:auto">
            <table class="tbl">
                <thead><tr>
                    <th>ID</th><th>Player</th>
                    <th>Goals</th><th>Saves</th><th>Rounds</th><th>Lifelines</th>
                    <th>Date</th><th>Actions</th>
                </tr></thead>
                <tbody id="scores-tbody">
                    <tr><td colspan="8" style="text-align:center;color:var(--dim);padding:24px">Loading...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal" id="del-modal">
    <div class="modal-box">
        <h3>Delete this score?</h3>
        <p>This cannot be undone.</p>
        <div class="modal-actions">
            <button class="btn btn-ghost" onclick="document.getElementById('del-modal').classList.remove('show')">Cancel</button>
            <button class="btn btn-acc"   id="confirm-del">Delete</button>
        </div>
    </div>
</div>

<script>
let allScores = [], deleteId = null;
const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

async function loadScores() {
    const d = await fetch('../api/admin.php?action=get_scores').then(r => r.json());
    allScores = d.scores || [];
    render(allScores);
}

function render(scores) {
    const tbody = document.getElementById('scores-tbody');
    if (!scores.length) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--dim);padding:24px">No results.</td></tr>';
        return;
    }
    tbody.innerHTML = scores.map(r => `
        <tr id="row-${r.id}">
            <td style="color:var(--dim);font-size:12px">${r.id}</td>
            <td><strong>${esc(r.username)}</strong></td>
            <td><input class="edit-input" id="g-${r.id}"  value="${r.goals_scored}"   type="number" min="0"></td>
            <td><input class="edit-input" id="s-${r.id}"  value="${r.goals_saved}"    type="number" min="0"></td>
            <td><input class="edit-input" id="r-${r.id}"  value="${r.rounds_played}"  type="number" min="0"></td>
            <td><input class="edit-input" id="q-${r.id}"  value="${r.lifelines_used}" type="number" min="0"></td>
            <td style="color:var(--dim);font-size:12px">${new Date(r.played_at).toLocaleDateString()}</td>
            <td style="white-space:nowrap">
                <button class="save-row" onclick="saveRow(${r.id})">Save</button>
                <span class="save-fb" id="fb-${r.id}"></span>
                <button class="btn-del" onclick="showDel(${r.id})" style="margin-left:5px">Del</button>
            </td>
        </tr>`).join('');
}

async function saveRow(id) {
    const body = new FormData();
    body.append('action',         'edit_score');
    body.append('id',             id);
    body.append('goals_scored',   document.getElementById(`g-${id}`).value);
    body.append('goals_saved',    document.getElementById(`s-${id}`).value);
    body.append('rounds_played',  document.getElementById(`r-${id}`).value);
    body.append('lifelines_used', document.getElementById(`q-${id}`).value);
    body.append('final_score',    document.getElementById(`g-${id}`).value); // goals = rank metric
    const d = await fetch('../api/admin.php', { method: 'POST', body }).then(r => r.json());
    const fb = document.getElementById(`fb-${id}`);
    fb.style.cssText = `display:inline;color:${d.success ? 'var(--accent)' : 'var(--red)'}`;
    fb.textContent   = d.success ? 'saved' : 'error';
    setTimeout(() => fb.style.display = 'none', 2000);
}

function showDel(id) { deleteId = id; document.getElementById('del-modal').classList.add('show'); }

document.getElementById('confirm-del').addEventListener('click', async () => {
    if (!deleteId) return;
    const body = new FormData();
    body.append('action', 'delete_score'); body.append('id', deleteId);
    await fetch('../api/admin.php', { method: 'POST', body });
    document.getElementById('del-modal').classList.remove('show');
    loadScores();
});

document.getElementById('search').addEventListener('input', e => {
    const q = e.target.value.toLowerCase();
    render(allScores.filter(s => s.username.toLowerCase().includes(q)));
});

async function loadLeaderboard() {
    const d = await fetch('../api/game.php?action=get_leaderboard').then(r => r.json());
    const tbody = document.getElementById('lb-tbody');
    if (!d.success || !d.leaderboard.length) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--dim);padding:20px">No data.</td></tr>';
        return;
    }
    tbody.innerHTML = d.leaderboard.map((r, i) => `
        <tr>
            <td style="color:var(--dim)">${i + 1}</td>
            <td><strong>${esc(r.username)}</strong></td>
            <td>${r.games_played}</td>
            <td><strong style="color:var(--accent)">${r.total_goals}</strong></td>
            <td>${r.total_saves}</td>
            <td>${r.total_lifelines}</td>
            <td style="color:var(--dim);font-size:12px">${new Date(r.last_played).toLocaleDateString()}</td>
        </tr>`).join('');
}

loadScores();
loadLeaderboard();
</script>
</body>
</html>
