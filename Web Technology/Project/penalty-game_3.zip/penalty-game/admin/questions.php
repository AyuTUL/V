<?php
require_once '../config.php';
requireAdmin();
$activePage = 'questions';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Questions — Admin</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="main">
    <div class="page-hd">
        <h1>Quiz Questions</h1>
        <p>Manage the football quiz questions shown as lifelines on missed shots</p>
    </div>

    <div class="card">
        <div class="card-hd"><span class="card-hd-title" id="form-title">Add Question</span></div>
        <div class="card-body">
            <div id="form-alert"></div>
            <div class="form-grid">
                <div class="field">
                    <label>Question</label>
                    <textarea id="f-q" rows="3" placeholder="e.g. How many players are on a football team?"></textarea>
                </div>
                <div class="form-2col">
                    <div class="field"><label>Option A</label><input type="text" id="f-a"></div>
                    <div class="field"><label>Option B</label><input type="text" id="f-b"></div>
                    <div class="field"><label>Option C</label><input type="text" id="f-c"></div>
                    <div class="field"><label>Option D</label><input type="text" id="f-d"></div>
                </div>
                <div class="field" style="max-width:160px">
                    <label>Correct Answer</label>
                    <select id="f-correct">
                        <option value="a">A</option><option value="b">B</option>
                        <option value="c">C</option><option value="d">D</option>
                    </select>
                </div>
                <div style="display:flex;gap:8px;align-items:center">
                    <button class="btn btn-acc" onclick="submitForm()">Save Question</button>
                    <button class="btn btn-ghost" onclick="resetForm()" id="cancel-btn" style="display:none">Cancel</button>
                    <input type="hidden" id="edit-id">
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-hd">
            <span class="card-hd-title">All Questions (<span id="q-count">0</span>)</span>
            <button class="btn btn-ghost" onclick="loadQuestions()" style="font-size:11px;padding:6px 14px">Refresh</button>
        </div>
        <div style="overflow-x:auto">
            <table class="tbl">
                <thead><tr>
                    <th style="width:32px">#</th>
                    <th>Question</th>
                    <th>A</th><th>B</th><th>C</th><th>D</th>
                    <th>Ans</th><th>Actions</th>
                </tr></thead>
                <tbody id="q-tbody">
                    <tr><td colspan="8" style="text-align:center;color:var(--dim);padding:24px">Loading...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal" id="del-modal">
    <div class="modal-box">
        <h3>Delete question?</h3>
        <p>This cannot be undone.</p>
        <div class="modal-actions">
            <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
            <button class="btn btn-acc"   id="confirm-del">Delete</button>
        </div>
    </div>
</div>

<script>
let questions = [], deleteId = null;
const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

async function loadQuestions() {
    const d = await fetch('../api/admin.php?action=get_questions').then(r => r.json());
    questions = d.questions || [];
    document.getElementById('q-count').textContent = questions.length;
    const tbody = document.getElementById('q-tbody');
    if (!questions.length) {
        tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--dim);padding:24px">No questions yet.</td></tr>';
        return;
    }
    const trunc = (s, n=55) => s.length > n ? s.slice(0, n) + '…' : s;
    tbody.innerHTML = questions.map((q, i) => `
        <tr>
            <td style="color:var(--dim);font-size:12px">${i + 1}</td>
            <td class="q-text" title="${esc(q.question)}">${esc(trunc(q.question))}</td>
            <td style="max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px">${esc(q.option_a)}</td>
            <td style="max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px">${esc(q.option_b)}</td>
            <td style="max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px">${esc(q.option_c)}</td>
            <td style="max-width:90px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px">${esc(q.option_d)}</td>
            <td><span class="badge badge-ok">${q.correct_answer.toUpperCase()}</span></td>
            <td style="white-space:nowrap">
                <button class="btn-edit" onclick="editQuestion(${q.id})">Edit</button>
                <button class="btn-del"  onclick="showModal(${q.id})">Del</button>
            </td>
        </tr>`).join('');
}

function editQuestion(id) {
    const q = questions.find(x => x.id == id); if (!q) return;
    document.getElementById('edit-id').value    = q.id;
    document.getElementById('f-q').value        = q.question;
    document.getElementById('f-a').value        = q.option_a;
    document.getElementById('f-b').value        = q.option_b;
    document.getElementById('f-c').value        = q.option_c;
    document.getElementById('f-d').value        = q.option_d;
    document.getElementById('f-correct').value  = q.correct_answer;
    document.getElementById('form-title').textContent      = 'Edit Question #' + id;
    document.getElementById('cancel-btn').style.display    = 'inline-block';
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resetForm() {
    ['edit-id','f-q','f-a','f-b','f-c','f-d'].forEach(id => document.getElementById(id).value = '');
    document.getElementById('f-correct').value             = 'a';
    document.getElementById('form-title').textContent      = 'Add Question';
    document.getElementById('cancel-btn').style.display    = 'none';
    document.getElementById('form-alert').innerHTML        = '';
}

async function submitForm() {
    const editId = document.getElementById('edit-id').value;
    const body   = new FormData();
    body.append('action',         editId ? 'update_question' : 'add_question');
    if (editId) body.append('id', editId);
    body.append('question',       document.getElementById('f-q').value.trim());
    body.append('option_a',       document.getElementById('f-a').value.trim());
    body.append('option_b',       document.getElementById('f-b').value.trim());
    body.append('option_c',       document.getElementById('f-c').value.trim());
    body.append('option_d',       document.getElementById('f-d').value.trim());
    body.append('correct_answer', document.getElementById('f-correct').value);
    const d = await fetch('../api/admin.php', { method: 'POST', body }).then(r => r.json());
    const alertEl = document.getElementById('form-alert');
    alertEl.innerHTML = d.success
        ? `<div class="alert alert-ok">${d.message}</div>`
        : `<div class="alert alert-err">${d.error}</div>`;
    if (d.success) { resetForm(); loadQuestions(); }
    setTimeout(() => alertEl.innerHTML = '', 3000);
}

function showModal(id)  { deleteId = id; document.getElementById('del-modal').classList.add('show'); }
function closeModal()   { deleteId = null; document.getElementById('del-modal').classList.remove('show'); }

document.getElementById('confirm-del').addEventListener('click', async () => {
    if (!deleteId) return;
    const body = new FormData();
    body.append('action', 'delete_question'); body.append('id', deleteId);
    await fetch('../api/admin.php', { method: 'POST', body });
    closeModal(); loadQuestions();
});

loadQuestions();
</script>
</body>
</html>
