<?php
require_once '../config.php';
requireAdmin();
$activePage = 'dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — Admin</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="main">
    <div class="page-hd">
        <h1>Dashboard</h1>
        <p>System overview</p>
    </div>

    <div class="stats-grid">
        <div class="stat-card"><div class="lbl">Total Players</div><div class="val g" id="s-users">—</div></div>
        <div class="stat-card"><div class="lbl">Games Played</div><div class="val"   id="s-games">—</div></div>
        <div class="stat-card"><div class="lbl">Quiz Questions</div><div class="val" id="s-questions">—</div></div>
        <div class="stat-card"><div class="lbl">Difficulty</div><div class="val" id="s-diff" style="font-size:18px">—</div></div>
    </div>

    <div class="card">
        <div class="card-hd">
            <span class="card-hd-title">Recent Games</span>
            <a href="scores.php" style="font-size:12px;color:var(--dim)">View all</a>
        </div>
        <div style="overflow-x:auto">
            <table class="tbl">
                <thead><tr>
                    <th>Player</th><th>Goals</th><th>Saves</th><th>Lifelines</th><th>Date</th>
                </tr></thead>
                <tbody id="recent-tbody">
                    <tr><td colspan="5" style="text-align:center;color:var(--dim);padding:24px">Loading...</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

async function load() {
    const [sd, rd] = await Promise.all([
        fetch('../api/admin.php?action=get_stats').then(r => r.json()),
        fetch('../api/admin.php?action=get_scores').then(r => r.json())
    ]);
    if (sd.success) {
        const s = sd.stats;
        document.getElementById('s-users').textContent     = s.total_users;
        document.getElementById('s-games').textContent     = s.total_games;
        document.getElementById('s-questions').textContent = s.total_questions;
        const dEl = document.getElementById('s-diff');
        dEl.textContent = s.goalie_difficulty.charAt(0).toUpperCase() + s.goalie_difficulty.slice(1);
        dEl.style.color = s.goalie_difficulty === 'easy' ? 'var(--accent)' : s.goalie_difficulty === 'hard' ? 'var(--red)' : 'var(--yellow)';
    }
    const tbody = document.getElementById('recent-tbody');
    if (!rd.success || !rd.scores.length) {
        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--dim);padding:24px">No games yet.</td></tr>';
        return;
    }
    tbody.innerHTML = rd.scores.slice(0, 8).map(r => `
        <tr>
            <td><strong>${esc(r.username)}</strong></td>
            <td>${r.goals_scored}</td>
            <td>${r.goals_saved}</td>
            <td>${r.lifelines_used}</td>
            <td style="color:var(--dim);font-size:12px">${new Date(r.played_at).toLocaleDateString()}</td>
        </tr>`).join('');
}
load();
</script>
</body>
</html>
