<?php
require_once '../config.php';
requireAdmin();
$activePage = 'settings';
$diff = getSetting('goalie_difficulty', 'medium');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keeper Difficulty — Admin</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="main">
    <div class="page-hd">
        <h1>Keeper Difficulty</h1>
        <p>Controls how often the AI goalkeeper dives to the correct zone</p>
    </div>

    <div class="card" style="max-width:500px">
        <div class="card-hd"><span class="card-hd-title">Difficulty Setting</span></div>
        <div id="diff-alert"></div>
        <div class="diff-opts">
            <?php foreach ([
                'easy'   => ['30% correct dives — very beatable',  'var(--accent)'],
                'medium' => ['50% correct dives — fair challenge',  'var(--yellow)'],
                'hard'   => ['75% correct dives — very difficult',  'var(--red)'],
            ] as $key => [$desc, $color]): ?>
            <div class="diff-opt">
                <div class="diff-opt-info">
                    <div class="name" style="color:<?= $color ?>"><?= ucfirst($key) ?></div>
                    <div class="desc"><?= $desc ?></div>
                </div>
                <button class="diff-pill <?= $diff === $key ? 'active' : '' ?>" data-diff="<?= $key ?>">
                    <?= $diff === $key ? 'Active' : 'Select' ?>
                </button>
            </div>
            <?php endforeach; ?>
        </div>
        <div style="padding:12px 18px;font-size:12px;color:var(--dim);border-top:1px solid var(--line)">
            Changes apply immediately to all new games.
            Current: <strong style="color:var(--text)"><?= ucfirst($diff) ?></strong>
        </div>
    </div>
</div>

<script>
document.querySelectorAll('.diff-pill').forEach(btn => btn.addEventListener('click', async () => {
    const body = new FormData();
    body.append('action',     'set_difficulty');
    body.append('difficulty', btn.dataset.diff);
    const d = await fetch('../api/admin.php', { method: 'POST', body }).then(r => r.json());
    const alertEl = document.getElementById('diff-alert');
    if (d.success) {
        document.querySelectorAll('.diff-pill').forEach(b => { b.classList.remove('active'); b.textContent = 'Select'; });
        btn.classList.add('active'); btn.textContent = 'Active';
        alertEl.innerHTML = `<div class="alert alert-ok" style="margin:0 18px 0">${d.message}</div>`;
    } else {
        alertEl.innerHTML = `<div class="alert alert-err" style="margin:0 18px 0">${d.error}</div>`;
    }
    setTimeout(() => alertEl.innerHTML = '', 3000);
}));
</script>
</body>
</html>
