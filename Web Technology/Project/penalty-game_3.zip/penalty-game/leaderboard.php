<?php
require_once 'config.php';
requireLogin();
$username = $_SESSION['username'];
$role     = $_SESSION['role'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard — Penalty Shootout</title>
    <link rel="stylesheet" href="css/auth.css">
    <style>body { display: block; overflow: auto; }</style>
</head>
<body>
<div class="lb-wrap">
    <div class="page-head">
        <h1>Leaderboard</h1>
        <a href="<?= $role === 'admin' ? 'admin/index.php' : 'game.php' ?>">
            &larr; back to <?= $role === 'admin' ? 'dashboard' : 'game' ?>
        </a>
    </div>
    <table class="lb-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Player</th>
                <th class="center">Games</th>
                <th class="center">Goals Scored</th>
                <th class="center">Saves</th>
                <th class="center">Lifelines Used</th>
                <th>Last Played</th>
            </tr>
        </thead>
        <tbody id="lb-body">
            <tr class="empty-row"><td colspan="7">Loading...</td></tr>
        </tbody>
    </table>
</div>
<script>
const ME  = <?= json_encode($username) ?>;
const esc = s => String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

fetch('api/game.php?action=get_leaderboard')
.then(r => r.json()).then(d => {
    const tbody = document.getElementById('lb-body');
    if (!d.success || !d.leaderboard.length) {
        tbody.innerHTML = '<tr class="empty-row"><td colspan="7">No games played yet.</td></tr>';
        return;
    }
    const rankClass = i => i === 0 ? 'rank-1' : i === 1 ? 'rank-2' : i === 2 ? 'rank-3' : 'rank-num';
    tbody.innerHTML = d.leaderboard.map((r, i) => `
        <tr class="${r.username === ME ? 'me' : ''}">
            <td><span class="${rankClass(i)}">${i + 1}</span></td>
            <td>
                ${esc(r.username)}
                ${r.username === ME ? '<span class="me-tag">YOU</span>' : ''}
            </td>
            <td class="center"><span class="stat-n">${r.games_played}</span></td>
            <td class="center"><span class="stat-n">${r.total_goals}</span></td>
            <td class="center"><span class="stat-n">${r.total_saves}</span></td>
            <td class="center"><span class="stat-n">${r.total_lifelines}</span></td>
            <td style="color:var(--dim);font-size:13px">${new Date(r.last_played).toLocaleDateString()}</td>
        </tr>`).join('');
}).catch(() => {
    document.getElementById('lb-body').innerHTML = '<tr class="empty-row"><td colspan="7">Failed to load.</td></tr>';
});
</script>
</body>
</html>
