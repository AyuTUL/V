<?php
require_once 'config.php';
startSession();
if (!empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . ($_SESSION['role'] === 'admin' ? 'admin/index.php' : 'game.php'));
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penalty Shootout</title>
    <link rel="stylesheet" href="css/auth.css">
</head>
<body>
<div class="wrap">
    <div class="wordmark">
        <div class="wordmark-pre">v1.0 &mdash; student project</div>
        <div class="wordmark-title">PENALTY<span>.</span>SHOOTOUT</div>
    </div>

    <div class="card">
        <div class="tabs">
            <button class="tab active" data-tab="login">Login</button>
            <button class="tab"        data-tab="register">Register</button>
        </div>
        <div class="tab-body">

            <div id="tab-login" class="tab-pane active">
                <div class="role-row">
                    <label class="role-opt active">
                        <input type="radio" name="role" value="user" checked>
                        <span class="role-dot"></span>
                        <span class="role-label">Player</span>
                    </label>
                    <label class="role-opt">
                        <input type="radio" name="role" value="admin">
                        <span class="role-dot"></span>
                        <span class="role-label">Admin</span>
                    </label>
                </div>
                <form id="loginForm">
                    <div class="field">
                        <label>Username</label>
                        <input type="text" id="l-user" autocomplete="username" required>
                    </div>
                    <div class="field">
                        <label>Password</label>
                        <input type="password" id="l-pass" autocomplete="current-password" required>
                    </div>
                    <div class="msg err" id="l-err"></div>
                    <button type="submit" class="btn">Enter</button>
                </form>
            </div>

            <div id="tab-register" class="tab-pane">
                <div class="note">Player accounts only. Admin accounts are created by the system administrator.</div>
                <form id="regForm">
                    <div class="field">
                        <label>Username</label>
                        <input type="text" id="r-user" autocomplete="username" required minlength="3" maxlength="50">
                    </div>
                    <div class="field">
                        <label>Password</label>
                        <input type="password" id="r-pass" autocomplete="new-password" required minlength="6">
                    </div>
                    <div class="msg err" id="r-err"></div>
                    <div class="msg ok"  id="r-ok"></div>
                    <button type="submit" class="btn">Create Account</button>
                </form>
            </div>

        </div>
    </div>
</div>

<script>
document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => {
    document.querySelectorAll('.tab, .tab-pane').forEach(el => el.classList.remove('active'));
    t.classList.add('active');
    document.getElementById('tab-' + t.dataset.tab).classList.add('active');
}));

document.querySelectorAll('input[name="role"]').forEach(r => r.addEventListener('change', () => {
    document.querySelectorAll('.role-opt').forEach(l => l.classList.remove('active'));
    r.closest('.role-opt').classList.add('active');
}));

document.getElementById('loginForm').addEventListener('submit', async e => {
    e.preventDefault();
    const err = document.getElementById('l-err'), btn = e.target.querySelector('button');
    err.textContent = ''; btn.disabled = true; btn.textContent = 'Loading...';
    const body = new FormData();
    body.append('action',        'login');
    body.append('username',      document.getElementById('l-user').value.trim());
    body.append('password',      document.getElementById('l-pass').value);
    body.append('expected_role', document.querySelector('input[name="role"]:checked').value);
    try {
        const d = await fetch('api/auth.php', { method: 'POST', body }).then(r => r.json());
        if (d.success) { window.location.href = d.redirect; return; }
        err.textContent = d.error;
    } catch { err.textContent = 'Connection error.'; }
    btn.disabled = false; btn.textContent = 'Enter';
});

document.getElementById('regForm').addEventListener('submit', async e => {
    e.preventDefault();
    const err = document.getElementById('r-err'), ok = document.getElementById('r-ok'), btn = e.target.querySelector('button');
    err.textContent = ok.textContent = ''; btn.disabled = true; btn.textContent = 'Creating...';
    const body = new FormData();
    body.append('action',   'register');
    body.append('username', document.getElementById('r-user').value.trim());
    body.append('password', document.getElementById('r-pass').value);
    try {
        const d = await fetch('api/auth.php', { method: 'POST', body }).then(r => r.json());
        if (d.success) { ok.textContent = d.message; e.target.reset(); }
        else err.textContent = d.error;
    } catch { err.textContent = 'Connection error.'; }
    btn.disabled = false; btn.textContent = 'Create Account';
});
</script>
</body>
</html>
