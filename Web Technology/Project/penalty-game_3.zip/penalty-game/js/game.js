// game.js — Penalty Shootout

let DIFFICULTY = 'medium';
const PREDICT  = { easy: 0.30, medium: 0.50, hard: 0.75 };

// Goal frame dimensions (must match CSS)
const GOAL_W = 560, GOAL_H = 220;
// Valid shot area (inside the posts — account for 8px border on each side)
const POST = 8;

const S = {
    phase: 'kick',
    goalsScored: 0, shotsSaved: 0, goalsConceeded: 0, roundsSurvived: 0, quizzesUsed: 0, seenQs: [],
    aimLocked: false, lockedX: 0, lockedY: 0,
    power: 0, powerDir: 1, charging: false, shotFired: false,
    keeperLocked: false, lockedKeeperX: 0,
    aiShotZone: 'left', goalieReady: false,
};

const $ = id => document.getElementById(id);

const kickPanel    = $('kick-panel'),    goaliePanel  = $('goalie-panel');
const kickFrame    = $('kick-goal-frame'),goalieFrame = $('goalie-goal-frame');
const kickAim      = $('kick-aim'),      kickAimMsg   = $('kick-aim-lock-msg');
const kickBall     = $('kick-ball'),     kickKeeper   = $('kick-keeper');
const powerWrap    = $('power-wrap'),    powerFill    = $('power-fill');
const phaseLabel   = $('phase-label'),   resultFlash  = $('result-flash');
const resultWord   = $('result-word'),   resultSub    = $('result-sub');
const goalieKeeper = $('goalie-keeper'), goalieCursor = $('goalie-cursor');
const goalieAiBall = $('goalie-ai-ball'),goalieCountdown = $('goalie-countdown');
const goalieLockMsg = $('goalie-lock-msg');
const quizModal    = $('quiz-modal'),    quizQ        = $('quiz-q');
const quizOpts     = $('quiz-opts'),     quizResult   = $('quiz-result');
const quizContinue = $('quiz-continue'), gameoverModal= $('gameover-modal');
const hudGoals     = $('hud-goals'),     hudSaves     = $('hud-saves');
const hudRounds    = $('hud-rounds'),    hudQuizzes   = $('hud-quizzes');

async function init() {
    try {
        const d = await fetch('api/game.php?action=get_settings').then(r => r.json());
        if (d.success) DIFFICULTY = d.goalie_difficulty;
    } catch {}
    updateHUD();
    startKick();
}

function updateHUD() {
    hudGoals.textContent   = S.goalsScored;
    hudSaves.textContent   = S.shotsSaved;
    hudRounds.textContent  = S.roundsSurvived;
    hudQuizzes.textContent = S.quizzesUsed;
}

// ── KICK PHASE ────────────────────────────────────────────
function startKick() {
    S.phase = 'kick'; S.aimLocked = false; S.shotFired = false;
    S.charging = false; S.power = 0; S.powerDir = 1;

    phaseLabel.textContent = 'Your kick — hover to aim, click to lock, SPACE to shoot';
    kickPanel.style.display  = 'flex';
    goaliePanel.style.display = 'none';

    kickAim.style.display = 'block';
    kickAim.style.left    = '280px';
    kickAim.style.bottom  = '70px';
    kickAim.classList.remove('locked');
    kickAimMsg.style.display = 'none';
    powerWrap.style.display  = 'none';
    powerFill.style.width    = '5%';

    resetKickBall();
    kickKeeper.style.left      = '240px';
    kickKeeper.style.transform = 'none';
    kickFrame.style.cursor     = 'crosshair';

    kickFrame.addEventListener('mousemove', onKickMove);
    kickFrame.addEventListener('click',     onKickClick);
}

function onKickMove(e) {
    if (S.aimLocked || S.shotFired) return;
    const r = kickFrame.getBoundingClientRect();
    kickAim.style.left   = Math.max(10, Math.min(e.clientX - r.left,  GOAL_W - 10)) + 'px';
    kickAim.style.bottom = Math.max(10, Math.min(r.height - (e.clientY - r.top), GOAL_H - 10)) + 'px';
}

function onKickClick(e) {
    if (S.aimLocked || S.shotFired) return;
    const r = kickFrame.getBoundingClientRect();
    S.lockedX = Math.max(10, Math.min(e.clientX - r.left,  GOAL_W - 10));
    S.lockedY = Math.max(10, Math.min(r.height - (e.clientY - r.top), GOAL_H - 10));
    S.aimLocked = true;

    kickAim.classList.add('locked');
    kickAim.style.left   = S.lockedX + 'px';
    kickAim.style.bottom = S.lockedY + 'px';
    kickFrame.removeEventListener('mousemove', onKickMove);
    kickFrame.removeEventListener('click',     onKickClick);
    kickFrame.style.cursor = 'default';

    kickAimMsg.style.display = 'block';
    powerWrap.style.display  = 'flex';

    // Power bar ticker — slower speed (was 3, now 1.2)
    (function tick() {
        if (!S.aimLocked || S.shotFired) return;
        if (S.charging) {
            S.power += S.powerDir * 1.2;
            if (S.power >= 100) { S.power = 100; S.powerDir = -1; }
            if (S.power <= 5)   { S.power = 5;   S.powerDir =  1; }
            powerFill.style.width = S.power + '%';
        }
        requestAnimationFrame(tick);
    })();
}

document.addEventListener('keydown', e => {
    if (e.code !== 'Space') return;
    e.preventDefault();
    if (S.phase === 'kick' && S.aimLocked && !S.shotFired) S.charging = true;
});

document.addEventListener('keyup', e => {
    if (e.code !== 'Space') return;
    if (S.phase !== 'kick' || !S.aimLocked || S.shotFired || !S.charging) return;
    S.charging = false;
    S.shotFired = true;
    executeKick();
});

function executeKick() {
    // Check if aim is inside the post boundaries
    const inPost = S.lockedX > POST && S.lockedX < (GOAL_W - POST) &&
                   S.lockedY > POST && S.lockedY < GOAL_H;

    const keeperZone = aiKeeperDecision(zone(S.lockedX, GOAL_W));
    const kpos = { left: '60px', center: '220px', right: '390px' };
    kickKeeper.style.left      = kpos[keeperZone];
    kickKeeper.style.transform = keeperZone === 'left' ? 'scaleX(-1)' : 'none';

    kickBall.style.cssText = 'display:block;transition:none;left:50%;bottom:-20px;transform:translateX(-50%) scale(1);opacity:1';
    requestAnimationFrame(() => {
        kickBall.style.cssText += ';transition:left .45s ease-out,bottom .45s ease-out,transform .45s,opacity .45s';
        kickBall.style.left      = S.lockedX + 'px';
        kickBall.style.bottom    = S.lockedY + 'px';
        kickBall.style.transform = 'translateX(0) scale(0.6) rotate(540deg)';
    });

    setTimeout(() => {
        if (!inPost) {
            // Shot missed the frame entirely
            flash('MISS', 'var(--dim)', 'Off target — lifeline quiz', () => triggerQuiz('kick_miss'));
            return;
        }
        const shotZone = zone(S.lockedX, GOAL_W);
        const isGoal   = shotZone !== keeperZone;
        if (isGoal) {
            S.goalsScored++;
            S.roundsSurvived++;
            updateHUD();
            flash('GOAL!', 'var(--accent)', '+1 goal — you stay as kicker', () => startKick());
        } else {
            flash('SAVED', 'var(--red)', 'Keeper got it — lifeline quiz', () => triggerQuiz('kick_miss'));
        }
    }, 520);
}

function resetKickBall() {
    kickBall.style.cssText = 'display:none;transition:none;left:50%;bottom:-20px;transform:translateX(-50%) scale(1)';
}

// ── GOALIE PHASE ──────────────────────────────────────────
let cdTimer = null, aiScheduled = false;

function startGoalie() {
    S.phase = 'goalie'; S.keeperLocked = false; S.goalieReady = false; aiScheduled = false;

    phaseLabel.textContent = "You're the keeper — hover to position, click to lock";
    kickPanel.style.display   = 'none';
    goaliePanel.style.display = 'flex';

    goalieKeeper.style.cssText    = 'left:240px;transform:none;transition:left .08s linear';
    goalieAiBall.style.display    = 'none';
    goalieCountdown.textContent   = '';
    goalieCountdown.style.display = 'block';
    goalieLockMsg.style.display   = 'none';
    goalieFrame.style.cursor      = 'crosshair';
    goalieCursor.style.display    = 'block';

    goalieFrame.addEventListener('mousemove', onGoalieMove);
    goalieFrame.addEventListener('click',     onGoalieClick);
    goalieFrame.addEventListener('mouseenter', () => goalieCursor.style.display = 'block');
    goalieFrame.addEventListener('mouseleave', () => goalieCursor.style.display = 'none');
}

function onGoalieMove(e) {
    if (S.keeperLocked) return;
    const r = goalieFrame.getBoundingClientRect();
    goalieKeeper.style.left = Math.max(0, Math.min(e.clientX - r.left - 40, 480)) + 'px';
    goalieCursor.style.left = (e.clientX - r.left) + 'px';
    goalieCursor.style.top  = (e.clientY - r.top)  + 'px';
}

function onGoalieClick(e) {
    if (S.keeperLocked) return;
    const r = goalieFrame.getBoundingClientRect();
    S.lockedKeeperX = Math.max(0, Math.min(e.clientX - r.left - 40, 480));
    S.keeperLocked  = true;

    goalieFrame.removeEventListener('mousemove', onGoalieMove);
    goalieFrame.removeEventListener('click',     onGoalieClick);
    goalieFrame.style.cursor       = 'default';
    goalieCursor.style.display     = 'none';
    goalieKeeper.style.left        = S.lockedKeeperX + 'px';
    goalieLockMsg.style.display    = 'block';

    let n = 3; goalieCountdown.textContent = n;
    clearInterval(cdTimer);
    cdTimer = setInterval(() => {
        n--;
        if (n > 0) { goalieCountdown.textContent = n; }
        else        { clearInterval(cdTimer); goalieCountdown.textContent = '!'; fireAI(); }
    }, 1000);
}

function fireAI() {
    if (aiScheduled) return; aiScheduled = true;
    if (!S.keeperLocked) {
        S.lockedKeeperX = parseInt(goalieKeeper.style.left) || 240;
        S.keeperLocked  = true;
        goalieFrame.removeEventListener('mousemove', onGoalieMove);
        goalieFrame.removeEventListener('click',     onGoalieClick);
    }
    const zones = ['left', 'center', 'right'];
    S.aiShotZone = zones[Math.floor(Math.random() * 3)];
    const tx = { left: 80,  center: 248, right: 430 };
    const ty = { left: 130, center: 90,  right: 130 };

    goalieAiBall.style.cssText = 'display:block;transition:none;left:50%;bottom:-30px;transform:translateX(-50%) scale(1)';
    requestAnimationFrame(() => {
        goalieAiBall.style.transition = 'left .45s ease-out,bottom .45s ease-out,transform .45s';
        goalieAiBall.style.left       = tx[S.aiShotZone] + 'px';
        goalieAiBall.style.bottom     = ty[S.aiShotZone] + 'px';
        goalieAiBall.style.transform  = 'scale(0.65) rotate(540deg)';
    });

    setTimeout(() => {
        const isSave = zone(S.lockedKeeperX + 40, GOAL_W) === S.aiShotZone;
        goalieCountdown.style.display = 'none';
        if (isSave) {
            S.shotsSaved++;
            S.roundsSurvived++;
            updateHUD();
            flash('SAVED!', 'var(--accent)', '+1 save — now you kick', () => startKick());
        } else {
            S.goalsConceeded++;
            flash('CONCEDED', 'var(--red)', 'Shot went in — lifeline quiz', () => triggerQuiz('goalie_miss'));
        }
    }, 520);
}

// ── RESULT FLASH ──────────────────────────────────────────
function flash(word, color, sub, cb) {
    resultWord.textContent = word;
    resultWord.style.color = color;
    resultSub.textContent  = sub;
    resultFlash.classList.add('show');
    setTimeout(() => {
        resultFlash.classList.remove('show');
        setTimeout(cb, 220);
    }, 1400);
}

// ── QUIZ ──────────────────────────────────────────────────
let curQuestion = null, quizCtx = '';

async function triggerQuiz(ctx) {
    quizCtx = ctx; S.phase = 'quiz'; S.quizzesUsed++; updateHUD();
    quizModal.classList.add('show');
    quizQ.textContent = 'Loading...'; quizOpts.innerHTML = '';
    quizResult.style.display = 'none'; quizContinue.style.display = 'none';
    try {
        const body = new FormData();
        body.append('action',  'get_quiz');
        body.append('exclude', S.seenQs.join(','));
        const d = await fetch('api/game.php', { method: 'POST', body }).then(r => r.json());
        if (!d.success) { quizQ.textContent = d.error || 'No questions available.'; return; }
        curQuestion = d.question;
        S.seenQs.push(curQuestion.id);
        quizQ.textContent = curQuestion.question;
        quizOpts.innerHTML = '';
        ['a','b','c','d'].forEach(l => {
            const el = document.createElement('div');
            el.className = 'quiz-opt';
            el.dataset.answer = l;
            el.innerHTML = `<span class="opt-key">${l.toUpperCase()}</span>${curQuestion['option_' + l]}`;
            el.addEventListener('click', () => submitAnswer(l, el));
            quizOpts.appendChild(el);
        });
    } catch { quizQ.textContent = 'Failed to load question.'; }
}

async function submitAnswer(ans, el) {
    document.querySelectorAll('.quiz-opt').forEach(o => o.style.pointerEvents = 'none');
    const body = new FormData();
    body.append('action',      'check_answer');
    body.append('question_id', curQuestion.id);
    body.append('answer',      ans);
    const d = await fetch('api/game.php', { method: 'POST', body }).then(r => r.json());
    el.classList.add(d.correct ? 'correct' : 'wrong');
    if (!d.correct)
        document.querySelectorAll('.quiz-opt').forEach(o => {
            if (o.dataset.answer === d.correct_answer) o.classList.add('reveal');
        });
    quizResult.style.display = 'block';
    if (d.correct) {
        quizResult.className   = 'quiz-result win';
        quizResult.textContent = quizCtx === 'kick_miss' ? 'Correct — shoot again!' : 'Correct — you stay as keeper!';
        quizContinue.style.display = 'block';
        quizContinue.textContent   = 'Continue';
        quizContinue.onclick = () => {
            quizModal.classList.remove('show');
            quizCtx === 'kick_miss' ? startKick() : startGoalie();
        };
    } else {
        quizResult.className   = 'quiz-result lose';
        quizResult.textContent = quizCtx === 'kick_miss' ? 'Wrong — you are now the keeper.' : 'Wrong — game over!';
        quizContinue.style.display = 'block';
        quizContinue.textContent   = quizCtx === 'kick_miss' ? 'Go to Keeper' : 'See Score';
        quizContinue.onclick = () => {
            quizModal.classList.remove('show');
            quizCtx === 'kick_miss' ? startGoalie() : endGame();
        };
    }
}

// ── GAME OVER ─────────────────────────────────────────────
async function endGame() {
    S.phase = 'over';
    kickPanel.style.display = goaliePanel.style.display = 'none';
    try {
        const body = new FormData();
        body.append('action',         'save_score');
        body.append('goals_scored',   S.goalsScored);
        body.append('goals_saved',    S.shotsSaved);
        body.append('goals_conceded', S.goalsConceeded);
        body.append('rounds_played',  S.roundsSurvived);
        body.append('lifelines_used', S.quizzesUsed);
        await fetch('api/game.php', { method: 'POST', body });
    } catch {}

    const total = S.goalsScored + S.shotsSaved;
    $('go-title').textContent   = total >= 12 ? 'Outstanding' : total >= 6 ? 'Decent Run' : 'Full Time';
    $('go-goals').textContent   = S.goalsScored;
    $('go-saves').textContent   = S.shotsSaved;
    $('go-conceded').textContent = S.goalsConceeded;
    $('go-rounds').textContent  = S.roundsSurvived;
    $('go-quizzes').textContent = S.quizzesUsed;
    gameoverModal.classList.add('show');
}

$('btn-play-again').addEventListener('click', () => {
    gameoverModal.classList.remove('show');
    Object.assign(S, {
        phase: 'kick', goalsScored: 0, shotsSaved: 0, goalsConceeded: 0,
        roundsSurvived: 0, quizzesUsed: 0, seenQs: [],
        aimLocked: false, lockedX: 0, lockedY: 0,
        power: 0, powerDir: 1, charging: false, shotFired: false,
        keeperLocked: false, lockedKeeperX: 0, goalieReady: false,
    });
    updateHUD();
    startKick();
});

// ── HELPERS ───────────────────────────────────────────────
function zone(x, w) {
    return x < w / 3 ? 'left' : x < w * 2 / 3 ? 'center' : 'right';
}

function aiKeeperDecision(shotZone) {
    if (Math.random() < (PREDICT[DIFFICULTY] ?? 0.5)) return shotZone;
    return ['left','center','right'].filter(z => z !== shotZone)[Math.floor(Math.random() * 2)];
}

function logout() {
    fetch('api/auth.php', { method: 'POST', body: new URLSearchParams({ action: 'logout' }) })
    .then(r => r.json()).then(d => window.location.href = d.redirect);
}

init();
