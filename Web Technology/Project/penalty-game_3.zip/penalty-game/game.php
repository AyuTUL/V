<?php
require_once 'config.php';
requireLogin();
if ($_SESSION['role'] === 'admin') { header('Location: ' . BASE_URL . 'admin/index.php'); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penalty Shootout</title>
    <link rel="stylesheet" href="css/game.css">
</head>
<body>

<div class="hud">
    <div class="hud-left">
        <span class="hud-stat">Goals <b class="g" id="hud-goals">0</b></span>
        <span class="hud-stat">Saves <b class="g" id="hud-saves">0</b></span>
    </div>
    <div class="hud-logo">PENALTY<span>.</span>SHOOTOUT</div>
    <div class="hud-right">
        <span class="hud-stat">Rounds <b id="hud-rounds">0</b></span>
        <span class="hud-stat">Lifelines <b class="r" id="hud-quizzes">0</b></span>
        <a href="leaderboard.php" class="hud-btn accent">Scores</a>
        <button class="hud-btn" onclick="logout()">Logout</button>
    </div>
</div>

<div id="game-area">
    <div id="phase-label">Your kick — hover to aim, click to lock, SPACE to shoot</div>

    <div id="result-flash">
        <div id="result-word">GOAL!</div>
        <div id="result-sub"></div>
    </div>

    <!-- KICK PANEL -->
    <div id="kick-panel">
        <div id="kick-goal-container">
            <div id="kick-goal-frame">
                <div id="kick-aim"><div class="aim-ring"></div></div>
                <div id="kick-keeper"></div>
                <div id="kick-ball"></div>
            </div>
        </div>
        <div id="kick-aim-lock-msg" class="inst-msg">Position locked — hold <kbd>SPACE</kbd> to charge, release to shoot</div>
        <div id="power-wrap">
            <div id="power-label">Power</div>
            <div id="power-track"><div id="power-fill"></div></div>
        </div>
    </div>

    <!-- GOALIE PANEL -->
    <div id="goalie-panel">
        <div id="goalie-goal-container">
            <div id="goalie-goal-frame">
                <div id="goalie-keeper"></div>
                <div id="goalie-ai-ball"></div>
                <div id="goalie-cursor"></div>
            </div>
        </div>
        <div id="goalie-lock-msg" class="inst-msg">Position locked — AI shoots in <span id="goalie-countdown">3</span></div>
    </div>
</div>

<!-- QUIZ MODAL -->
<div id="quiz-modal">
    <div class="quiz-card">
        <div class="quiz-top">
            <span class="quiz-tag">Quiz Lifeline</span>
            <span class="quiz-hint">Answer correctly to stay in</span>
        </div>
        <div class="quiz-body">
            <div class="quiz-q" id="quiz-q"></div>
            <div class="quiz-opts" id="quiz-opts"></div>
            <div class="quiz-result" id="quiz-result"></div>
        </div>
        <button id="quiz-continue">Continue</button>
    </div>
</div>

<!-- GAME OVER -->
<div id="gameover-modal">
    <div class="go-card">
        <div class="go-label">Full Time</div>
        <div class="go-title" id="go-title">Game Over</div>
        <div class="go-stats">
            <div class="go-stat"><div class="go-stat-n" id="go-goals">0</div><div class="go-stat-l">Goals Scored</div></div>
            <div class="go-stat"><div class="go-stat-n" id="go-saves">0</div><div class="go-stat-l">Saves Made</div></div>
            <div class="go-stat"><div class="go-stat-n" id="go-conceded">0</div><div class="go-stat-l">Conceded</div></div>
            <div class="go-stat"><div class="go-stat-n" id="go-rounds">0</div><div class="go-stat-l">Rounds</div></div>
            <div class="go-stat"><div class="go-stat-n" id="go-quizzes">0</div><div class="go-stat-l">Lifelines Used</div></div>
        </div>
        <div class="go-btns">
            <button class="go-btn-primary" id="btn-play-again">Play Again</button>
            <a href="leaderboard.php" class="go-btn-secondary">View Leaderboard</a>
        </div>
    </div>
</div>

<script src="js/game.js"></script>
</body>
</html>
